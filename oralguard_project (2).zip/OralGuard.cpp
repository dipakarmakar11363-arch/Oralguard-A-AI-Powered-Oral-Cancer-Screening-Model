// =======================================================
// OralGuard - Oral Cancer Risk Screening Tool
// Language: C++ (Standard C++11 / C++17 / C++20)
// Designed for console execution and medical screening logic
// =======================================================

#include <iostream>
#include <string>

using namespace std;

int main() {
    cout << "========================================" << endl;
    cout << "              ORALGUARD                 " << endl;
    cout << "     Oral Cancer Risk Screening Tool    " << endl;
    cout << "========================================" << endl << endl;

    int score = 0;
    int redFlags = 0;
    char choice;

    // 1. Tobacco habits
    cout << "1. Do you use tobacco products (cigarettes, bidi, chewing tobacco, gutkha)? (y/n): ";
    cin >> choice;
    bool tobacco = (choice == 'y' || choice == 'Y');
    if (tobacco) {
        score += 25;
    }

    // 2. Alcohol habits
    cout << "2. Do you drink alcohol frequently or heavily? (y/n): ";
    cin >> choice;
    bool alcohol = (choice == 'y' || choice == 'Y');
    if (alcohol) {
        score += 15;
    }

    // Tobacco + Alcohol synergy multiplier
    if (tobacco && alcohol) {
        score += 15;
    }

    // 3. Persistent mouth ulcer (> 14 days)
    cout << "3. Do you have a mouth sore or ulcer lasting more than 2 weeks? (y/n): ";
    cin >> choice;
    bool ulcer = (choice == 'y' || choice == 'Y');
    if (ulcer) {
        score += 35;
        redFlags++;
    }

    // 4. White or red patches
    cout << "4. Have you noticed persistent red or white patches in your mouth? (y/n): ";
    cin >> choice;
    if (choice == 'y' || choice == 'Y') {
        score += 30;
        redFlags++;
    }

    // 5. Lump or induration
    cout << "5. Do you feel a firm lump or swelling in your cheek, tongue, or neck? (y/n): ";
    cin >> choice;
    if (choice == 'y' || choice == 'Y') {
        score += 25;
        redFlags++;
    }

    // 6. Swallowing difficulty
    cout << "6. Do you have persistent difficulty or pain when swallowing? (y/n): ";
    cin >> choice;
    if (choice == 'y' || choice == 'Y') {
        score += 20;
    }

    // 7. Unexplained numbness
    cout << "7. Do you experience unexplained numbness in your mouth or tongue? (y/n): ";
    cin >> choice;
    if (choice == 'y' || choice == 'Y') {
        score += 15;
    }

    // Cap maximum score at 100
    if (score > 100) score = 100;

    cout << "\n----------------------------------------" << endl;
    cout << "SCREENING RESULTS:" << endl;
    cout << "Total Calculated Score: " << score << "/100" << endl;

    if (score >= 55 || redFlags >= 2 || ulcer) {
        cout << "STATUS: HIGH RISK" << endl;
        cout << "Action: Prompt physical examination by a dentist or oral surgeon is advised." << endl;
    } else if (score >= 25 || redFlags == 1) {
        cout << "STATUS: MODERATE RISK" << endl;
        cout << "Action: Monitor your symptoms closely. If sores persist past 14 days, see a doctor." << endl;
    } else {
        cout << "STATUS: LOW RISK" << endl;
        cout << "Action: Maintain daily oral hygiene and routine 6-month dental checkups." << endl;
    }
    cout << "----------------------------------------" << endl;
    cout << "\nNote: OralGuard is an educational screening tool and does not provide a medical diagnosis.\n";

    return 0;
}
